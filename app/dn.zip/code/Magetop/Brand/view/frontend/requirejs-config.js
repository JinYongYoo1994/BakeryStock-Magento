/**
 * Copyright © 2015 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */
var config = {
	map: {
		"*": {
			conflict: "Magetop_Brand/js/conflict",
			owlcarousel: "Magetop_Brand/js/owl.carousel",
			boostrap: "Magetop_Brand/js/bootstrap.min",
		}
	}
};