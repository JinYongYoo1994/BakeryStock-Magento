/**
 * Copyright © 2018 Cardknox Development Inc. All rights reserved.
 * See LICENSE for license details.
 */
var config = {
    paths: {
        ifields: 'https://cdn.cardknox.com/ifields/2.3.1808.0101/ifields.min'
    }
};