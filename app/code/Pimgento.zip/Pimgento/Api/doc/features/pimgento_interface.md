# PIMGento2 (API) Interface

### Locate and use the interface:

* PIMGento2 (API) Import Interface is located at System > PIMGento > Import

![pimgento-interface](PIMGento2-API-interface-M2.png)

* Select your import type from the list
* ***Import*** launch the import

* Once you launch your import you can follow the import progress with the console.
>  DO NOT CLOSE THE BROWSER WINDOW WHILE THE IMPORT IS STILL ON!
* If an error appears, you can easily identify at which task the problem occurred. You can check your logs files if you want further informations.