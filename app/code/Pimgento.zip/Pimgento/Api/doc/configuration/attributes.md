# Attributes

Configuration is available in Magento 2 back-office under:
* Stores > Catalog > Pimgento > Attributes

| Configuration         | Usage                                              |
|-----------------------|----------------------------------------------------|
| Additional types      | Mapping between PIM attributes and Magento types   |