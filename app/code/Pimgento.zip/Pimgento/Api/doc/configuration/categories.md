# Categories

Configuration is available in Magento 2 back-office under:
* Stores > Catalog > Pimgento > Categories

| Configuration                     | Usage                                                          |
|-----------------------------------|----------------------------------------------------------------|
| Activate new categories           | Newly imported categories will be activated                    |
| Include new categories in menu    | Newly imported categories categories will be included in menu  |
| Set new categories in anchor mode | Newly imported categories will be in anchor mode               |